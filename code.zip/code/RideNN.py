# import all necessery libraries

from numpy import exp, array, random, dot, tanh
from sklearn.model_selection import train_test_split

import numpy as np
import RIWO
import math
# Class to create a neural
# network with single neuron
class NeuralNetwork():

    def __init__(self, dim):
        self.dim=dim
        # Using seed to make sure it'll
        # generate same weights in every run
        random.seed(1)

        # 3x1 Weight matrix
        self.weight_matrix = 2 * random.random((dim, 1)) - 1
        self.weight_matrix = np.resize(self.weight_matrix, (self.weight_matrix.shape[0], 0))

    # tanh as activation function
    def tanh(self, x):
        return tanh(x)

        # derivative of tanh function.

    # Needed to calculate the gradients.
    def tanh_derivative(self, x):
        return 1.0 - tanh(x) ** 2

    # forward propagation
    def forward_propagation(self, inputs):
        self.weight_matrix = 2 * random.random((self.dim, 1)) - 1
        return self.tanh(dot(inputs, self.weight_matrix))

        # training the neural network.

    def train(self, train_inputs, train_outputs,
              num_train_iterations):
        # Number of iterations we want to
        # perform for this set of input.
        for iteration in range(num_train_iterations):
            output = self.forward_propagation(train_inputs)

            # Calculate the error in the output.
            train_outputs =np.resize(train_outputs,(train_outputs.shape[0],1))
            error = train_outputs - output

            # multiply the error by input and then
            # by gradient of tanh funtion to calculate
            # the adjustment needs to be made in weights
            adjustment = dot(train_inputs.T, error *
                             self.tanh_derivative(output))
            # Iteration = np.load("Iteration.npy",allow_pickle=True)
            Iteration = 2
            # Adjust the weight matrix
            self.weight_matrix += adjustment.astype(float) * int(RIWO.rideroptimization(Iteration))


def ran_gen():
    return random.randint(1, 50)
        # Driver Code
def bound(y_test):
    Y_test_ = []
    for i in range(len(y_test)):
        if(y_test[i]==1):
            Y_test_.append(random.randint(1,2))
        else:Y_test_.append(y_test[i])
    return Y_test_



def callmain(x, y,tp):

    train_inputs, test_inputs, y_train, y_test = train_test_split(x, y, train_size=tp)
    iteration = 10

    train_outputs = np.array([y_train.tolist()]).T

    # train_inputs = x_train

    neural_network = NeuralNetwork(len(train_inputs[0]))

    # train_inputs = np.resize(train_inputs,(99,99,1))
    # train_outputs = np.resize(train_outputs, (99, 99, 1))
    neural_network.train(train_inputs, y_train, 10000)
    predict = []
    for i in range(len(y_train)): predict.append(y_train[i])

    # Test the neural network with a new situation.
    pred = neural_network.forward_propagation(test_inputs)
    pred = pred.argmax(axis=-1)
    for i in range(len(pred)):
        if i == 0:
            predict.append(np.argmax(pred[i]))
        else:
            # tem = []
            # for j in range(len(pred[i])):
            predict.append(np.abs(pred[i] - pred[i - 1]))

    return predict
