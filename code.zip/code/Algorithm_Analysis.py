import pandas as pd
import pandas_ta
import random
import CSA_BiLSTM.BiLSTM
import AOA_BiLSTM.BiLSTM
import JSO_BiLSTM.BiLSTM
import Proposed_RSJSO_BiLSTM.BiLSTM
import RSO_BiLSTM.BiLSTM
import numpy as np

import features, Fusion, Augmentation

mse_all = np.zeros((5,5))
rmse_all = np.zeros((5,5))
mape_all = np.zeros((5,5))
rae_all = np.zeros((5,5))


df = pd.read_csv('data\weatherAUS.csv')  #####read data

lab = df.iloc[:, -2]  ### target from data
lab = np.nan_to_num(lab)

df = df.drop(['RainToday'], axis=1)
for i in range(len(lab)):
    if lab[i] == 'No':
        lab[i] = float(0)
    elif lab[i] == 'Yes':
        lab[i] = float(1)
    else:
        lab[i] = float(0)
#####  to remove string from the dataframe
cols = [0, 1, 7, 9, 10, 21]
for col in cols:
    uni = []
    for i in range(len(df)):
        if df.iloc[i, col] in uni:
            df.iloc[i, col] = uni.index(df.iloc[i, col])
        else:
            uni.append(df.iloc[i, col])
            df.iloc[i, col] = uni.index(df.iloc[i, col])

############## pre processing using missing data imputation
processed_df = df.fillna(df.median())  ########## missing data imputation -- median
processed_df = processed_df.astype('int')

######## feat extraction
data = np.array(processed_df)
feat = []  # initializing
for i in range(len(data[0])):  # for loop for each column
    dat = data[:, i]  # column values
    dta = pd.DataFrame(data=dat, columns=["price"])  # setting the column as price in the dataframe
    #### converting numpy array to dataframe ##
    a = []  # High price
    for i in range(len(dat)):
        a.append(dat[i] + 1)
    nn = np.column_stack((dat, a))
    b = []  # Low price
    for i in range(len(dat)):
        b.append(dat[i] - 1)
    nnn = np.column_stack((nn, b))
    c = []  # Close price
    for i in range(len(dat)):
        l = dat[i] - 1
        h = dat[i] + 1
        c.append(random.uniform(l, h))
    new = np.column_stack((nnn, c))  # joining High, low , Close price

    df = pd.DataFrame(data=new, columns=["price", "High", "Low", "Close"])  # creating dataframe

f1 = pandas_ta.rsi(df['Close'])  ##### rsi
f2 = pandas_ta.linreg(df['Close'])  ###### linear regression slope
f3 = pandas_ta.trix(df['Close'])  #### TRIX
f4 = pandas_ta.willr(df['High'], df['Low'], df['Close'])  ####  Williams % R
f5 = pandas_ta.dema(df['Close'])  #####    double exponential moving average
f6 = features.wilders_smoothing(np.array(df), 3)  #####   Welles Wilder’s smoothing Average
f7 = pandas_ta.uo(df['High'], df['Low'], df['Close'])  ####  Ultimate Oscillator
f8 = pandas_ta.macd(df['Close'])  ####   moving average convergence divergence

feat = pd.concat([f1, f2, f3, f4, f5, f6, f7, f8], axis=1)  #####  concatenating features
feat = np.nan_to_num(feat)

#########  fusion using rideNN and chord distance
S = 10
fused_feat = Fusion.feature(feat, S, lab)

######### Augmentation using SMOTE method
augmented_data, augmented_target = Augmentation.augment(fused_feat, lab, size=200000)

tr = 0.5
iter =10
for i in range(5):
    print(i)

    ####### algorithm analysis
    mse1, rmse1, mape1, Rae1 = CSA_BiLSTM.BiLSTM.classify(augmented_data, augmented_target, tr, iter)
    mse2, rmse2, mape2, Rae2 = AOA_BiLSTM.BiLSTM.classify(augmented_data, augmented_target, tr, iter)
    mse3, rmse3, mape3, Rae3 = JSO_BiLSTM.BiLSTM.classify(augmented_data, augmented_target, tr, iter)
    mse4, rmse4, mape4, Rae4 = RSO_BiLSTM.BiLSTM.classify(augmented_data, augmented_target, tr, iter)
    mse5, rmse5, mape5, Rae5 = Proposed_RSJSO_BiLSTM.BiLSTM.classify(augmented_data, augmented_target, tr, iter)


   
    mse_all[i, :] = [mse1, mse2, mse3, mse4, mse5]
    rmse_all[i, :] = [rmse1, rmse2, rmse3, rmse4, rmse5]
    mape_all[i, :] = [mape1, mape2, mape3, mape4, mape5]
    rae_all[i, :] = [Rae1, Rae2, Rae3, Rae4, Rae5]
    tr = tr + 0.1
    iter = iter+10






