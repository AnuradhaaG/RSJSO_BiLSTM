import random

import numpy as np

class RSO:
    def __init__(self, objective_function, num_variables, num_rats=50, max_iterations=100):
        self.objective_function = objective_function
        self.num_variables = num_variables
        self.num_rats = num_rats
        self.max_iterations = max_iterations
        self.best_position = None
        self.best_fitness = float('inf')

    def initialize_population(self):
        return np.random.rand(self.num_rats, self.num_variables)

    def update_parameters(self, x):
        # Update parameters A and C
        # You may define Equations (10) and (11) here
        # For demonstration, we'll use fixed values
        R = random.uniform(1, 5)
        A = R - x * (R / self.max_iterations)
        C = 2 * random.random()
        return R, A, C

    def move_rats(self, rats, A, C, prev_best_position):
        P = A * rats + C * (prev_best_position - rats)  ### eqn 9
        new_rats = np.abs(prev_best_position - P)   ##### eqn 8
        return new_rats

    def optimize(self):
        # Generate initial population
        rats = self.initialize_population()



        # Main optimization loop
        iteration = 0
        while iteration < self.max_iterations:
            # Calculate the fitness value of each search agent
            fitness_values = np.array([self.objective_function(rat) for rat in rats])

            # Update the best search agent
            best_index = np.argmin(fitness_values)
            if fitness_values[best_index] < self.best_fitness:
                self.best_position = rats[best_index].copy()
                self.best_fitness = fitness_values[best_index]

            # Update parameters A and C
            R,A, C = self.update_parameters(iteration)

            # Move rats
            rats = self.move_rats(rats, A, C, self.best_position)

            iteration += 1

        return self.best_position, self.best_fitness

# Example usage:
def objective_function(x):
    # Example objective function (minimization problem)
    return np.sum(x**2)
def opt(iter):
    # Define algorithm parameters
    N = 50
    max_iterations = iter

    # Initialize RSO optimizer
    optimizer = RSO(objective_function, num_variables=5, num_rats=N, max_iterations=max_iterations)

    # Perform optimization
    best_position, best_fitness = optimizer.optimize()

    return best_fitness