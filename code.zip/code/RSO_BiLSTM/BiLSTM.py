from sklearn.metrics import mean_squared_error,mean_absolute_percentage_error
from keras.optimizers import Adam as opt
import math
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential
from keras.layers import Dense, LSTM
from keras.layers import Dropout
from. import Rat_Swarm_opt

from keras.layers import Conv2D, MaxPooling2D, Bidirectional
def rae(actual, predicted):
    numerator = np.sum(np.abs(predicted - actual))
    denominator = np.sum(np.abs(np.mean(actual) - actual))
    return numerator / denominator
def classify(data, label,tr,iter):
    X_train, X_test, y_train, y_test = train_test_split(data,label, train_size=tr)
    target = y_test

    model = Sequential()
    model.add(Bidirectional(LSTM(
        units=10,
        return_sequences=True), input_shape=(1, 1)))
    # model.add(Dropout(0.5))
    model.add(Bidirectional(LSTM(
        units=5,
        return_sequences=False), input_shape=(1, 1)))
    # model.add(Dropout(0.5))
    model.add(Dense(units=1, activation="linear"))

    model.compile(loss='mean_squared_error', optimizer='RMSprop')
    lr = Rat_Swarm_opt.opt(iter)
    w = model.get_weights()
    w[0] = w[0]*lr
    model.set_weights(w)

    model.fit(X_train, (y_train).astype(int), epochs=1)
    pred = model.predict(X_test)
    target = y_test
    mse = mean_squared_error(target,pred)
    rmse = math.sqrt(mse)
    mape = mean_absolute_percentage_error(target,pred)
    Rae = rae(target,pred)

    return mse,rmse,mape,Rae



