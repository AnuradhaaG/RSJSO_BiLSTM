import sys, numpy as np
import sort_features
import RideNN

# Mean calculation
def get_mean(data):
    avg = []
    for i in range(len(data)): avg.append(np.mean(data[i]))  # mean data of attributes of same class
    return avg





def update_progress(job_title, progress):
    length = 20  # modify this to change the length
    block = int(round(length * progress))
    msg = "\r{0}: [{1}] {2}%".format(job_title, "#" * block + "-" * (length - block), round(progress * 100, 2))
    if progress >= 1: msg += " DONE\r\n"
    sys.stdout.write(msg)
    sys.stdout.flush( )


def feature(data, S, clas):

    print("\n Feature Fusion:")
    # arrange features by chord distance
    print("\t>> Chord Distance based feature sorting..")
    f = sort_features.by_Chord_Distance(data, clas).tolist( )

    print("\t>> Feature Fusion using Ride Neural network..wait..")
    T = len(f)
    F_new, l = [], round(T)

    alpha = RideNN.callmain(data, clas,0.99)  # alpha value prediction by Ride NN
    for m in range(len(f)):  # data size
        update_progress("\t\tFusion", m / (len(f) - 1))
        FF = []
        for n in range(S):  # n_features to be fused
            summ, i, g = 0, n, 1
            while g <= l:  # n attributes to fused as 1
                summ += ((alpha[m] / g) * f[m][i])
                if (i + S) < len(f[m]):
                    i = i + S  # S = N/j
                else:
                    g += l  # last set
                g += 1
            FF.append(summ)
        F_new.append(FF)
    F_new = np.array(F_new)

    return F_new
