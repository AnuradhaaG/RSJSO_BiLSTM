import numpy as np
import math
# chord distance
def chord_distance(x,y):
    a, b, c = 0, 0, 0
    for i in range(len(x)):
        a += x[i] * y[i]
        b += x[i] ** 2
        c += y[i] ** 2
    cd = math.sqrt(2 - 2 * (a/(math.sqrt(b*c))))
    return cd


def by_Chord_Distance(data, clas):

    data = np.transpose(data)   # transpose for attribute selection
    # data = np.array(data)


    coeff_value = []
    for i in range(len(data)):
        coeff_value.append(chord_distance(data[i], clas)) # chord distance value of attributes

    # Sort attribute by max
    des_coeff = coeff_value.copy()
    des_coeff.sort()
    des_coeff.reverse()     # sort the chord distance value in descending order

    # sorted index
    sort_index = []
    for i in range(len(des_coeff)):
        ind = coeff_value.index(des_coeff[i])     # index of sorted data
        sort_index.append(ind)
        coeff_value[ind] = -10000.0    # set by min value to avoid repeated value confusion

    # sort Attributes by sorted index
    sorted_attr = []
    for i in range(len(sort_index)):
        sorted_attr.append(data[sort_index[i]])   # add attribute according to the sorted index

    return np.transpose(sorted_attr)    # transpose to get its original form
