import pandas as pd,numpy as np
import math,random
import Augmentation
import pandas_ta
import features
import Fusion
import BiLSTM
def main(tr):
    df = pd.read_csv('data\weatherAUS.csv') #####read data

    lab = df.iloc[:,-2]   ### target from data
    lab = np.nan_to_num(lab)

    df = df.drop(['RainToday'], axis=1)
    for i in range(len(lab)):
        if lab[i] =='No':
            lab[i] = float(0)
        elif lab[i] =='Yes':
            lab[i]=float(1)
        else:
            lab[i] =float(0)
    #####  to remove string from the dataframe
    cols = [0,1,7,9,10,21]
    for col in cols:
        uni = []
        for i in range(len(df)):
            if df.iloc[i,col] in uni:
                df.iloc[i, col] = uni.index(df.iloc[i,col])
            else:
                uni.append(df.iloc[i,col])
                df.iloc[i, col] = uni.index(df.iloc[i,col])

    ############## pre processing using missing data imputation
    processed_df = df.fillna(df.median())  ########## missing data imputation -- median
    processed_df = processed_df.astype('int')

    ######## feat extraction
    data = np.array(processed_df)
    feat = [] # initializing
    for i in range(len(data[0])): # for loop for each column
        dat = data[:,i] # column values
        dta = pd.DataFrame(data=dat, columns=["price"]) # setting the column as price in the dataframe
        #### converting numpy array to dataframe ##
        a = [] # High price
        for i in range(len(dat)):
            a.append(dat[i]+1)
        nn = np.column_stack((dat,a))
        b = [] # Low price
        for i in range(len(dat)):
            b.append(dat[i]-1)
        nnn = np.column_stack((nn,b))
        c = [] # Close price
        for i in range(len(dat)):
            l = dat[i]-1
            h = dat[i]+1
            c.append(random.uniform(l,h))
        new = np.column_stack((nnn,c)) # joining High, low , Close price

        df = pd.DataFrame(data=new, columns=["price", "High","Low","Close"]) # creating dataframe


    f1 = pandas_ta.rsi(df['Close'])    ##### rsi
    f2 = pandas_ta.linreg(df['Close'])   ###### linear regression slope
    f3 = pandas_ta.trix(df['Close'])     #### TRIX
    f4 = pandas_ta.willr(df['High'],df['Low'],df['Close'])   ####  Williams % R
    f5 = pandas_ta.dema(df['Close'])   #####    double exponential moving average
    f6 = features.wilders_smoothing(np.array(df),3)   #####   Welles Wilder’s smoothing Average
    f7 = pandas_ta.uo(df['High'],df['Low'],df['Close']) ####  Ultimate Oscillator
    f8 = pandas_ta.macd(df['Close'])        ####   moving average convergence divergence

    feat = pd.concat([f1,f2,f3,f4,f5,f6,f7,f8],axis=1)   #####  concatenating features
    feat = np.nan_to_num(feat)

    #########  fusion using rideNN and chord distance
    S = 10
    fused_feat = Fusion.feature(feat,S,lab)


    ######### Augmentation using SMOTE method
    augmented_data,augmented_target =  Augmentation.augment(fused_feat,lab,size=200000)


    MSE,RMSE,MAPE,RAE = [], [], [], []

    ###### proposed BiLSTM model
    BiLSTM.classify(augmented_data, augmented_target, tr,MSE,RMSE,MAPE,RAE)

    return MSE,RMSE,MAPE,RAE
if __name__ == '__main__':
    tr = 0.5 ######### training data
    main(tr)