import random
import os
import numpy as np
# Function: Initialize Variables
def initial_position(jellyfishes = 5, min_values = [-5,-5], max_values = [5,5], eta = 4):
    position = np.zeros((jellyfishes, len(min_values)+1))
    x        = []
    for j in range(0, len(min_values)):
        x_0      = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
        while ([x_0] in [0.00, 0.25, 0.50, 0.75, 1.00]):
            x_0 = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
        x.append(x_0)
    for i in range(0, jellyfishes):
        for j in range(0, len(min_values)):
             x[j]          = eta*x[j]*(1 - x[j])
             b             = min_values[j]
             a             = max_values[j] - b
             position[i,j] = x[j]*a + b
        position[i,-1] = position[i,position.shape[1]-1]
    return position

############################################################################

# Function: Updtade Jellyfishes Position
def update_jellyfishes_position(position, best_position, beta, gamma, c_t, min_values, max_values):
    mu = position.mean(axis = 0)
    if (c_t >= 0.5):
        for i in range(0, position.shape[0]):
            for j in range(0, len(min_values)):
                rand_1        = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
                rand_2        = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
                position[i,j] = np.clip(position[i,j] + rand_1*(best_position[0, j] - beta*rand_2*mu[j]), min_values[j], max_values[j])
            position[i,-1] = position[i,position.shape[1]-1]
    else:
        rand = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
        if (rand > 1 - c_t):
            for i in range(0, position.shape[0]):
                for j in range(0, len(min_values)):
                    rand          = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
                    position[i,j] = np.clip(position[i,j] + gamma*rand*(max_values[j] - min_values[j]), min_values[j], max_values[j])
                position[i,-1] = position[i,position.shape[1]-1]
        else:
            for i in range(0, position.shape[0]):
                candidates = [item for item in list(range(0, position.shape[0])) if item != i]
                k          = random.choice(candidates)
                for j in range(0, len(min_values)):
                    rand = int.from_bytes(os.urandom(8), byteorder = 'big') / ((1 << 64) - 1)
                    if (position[i, -1] >= position[k, -1]):
                        direction = position[k, j] - position[i, j]
                    else:
                        direction = position[i, j] - position[k, j]
                    position[i, j] = np.clip(position[i, j] + rand*direction, min_values[j], max_values[j])
                position[i,-1] = position[i,position.shape[1]-1]
    return position

class algm:
    def __init__(self, objective_function, num_variables, num_rats=50, max_iterations=100):
        self.objective_function = objective_function
        self.num_variables = num_variables
        self.num_rats = num_rats
        self.max_iterations = max_iterations
        self.best_position = None
        self.best_fitness = float('inf')

    def initialize_population(self):
        return np.random.rand(self.num_rats, self.num_variables)

    def update_parameters(self, x):
        # Update parameters A and C
        # You may define Equations (10) and (11) here
        # For demonstration, we'll use fixed values
        R = random.uniform(1, 5)
        A = R - x * (R / self.max_iterations)
        C = 2 * random.random()
        return R, A, C

    def move_rats(self, rats, A, C, prev_best_position):
        beta = 3
        P = A * rats + C * (prev_best_position - rats)  ### eqn 9
        mu = rats.mean(axis=0)


        # new_rats = np.abs(prev_best_position - P)   ##### eqn 8
        new_rats = np.abs((prev_best_position *(C-1)+( random.uniform(0,1)*P -beta * random.uniform(0,1 )+mu ) *(C-A))/(C-A-1))
        return new_rats

    def optimize(self):
        # Generate initial population
        rats = self.initialize_population()



        # Main optimization loop
        iteration = 0
        while iteration < self.max_iterations:
            # Calculate the fitness value of each search agent
            fitness_values = np.array([self.objective_function(rat) for rat in rats])

            # Update the best search agent
            best_index = np.argmin(fitness_values)
            if fitness_values[best_index] < self.best_fitness:
                self.best_position = rats[best_index].copy()
                self.best_fitness = fitness_values[best_index]

            # Update parameters A and C
            R,A, C = self.update_parameters(iteration)

            # Move rats
            rats = self.move_rats(rats, A, C, self.best_position)

            iteration += 1

        return self.best_position, self.best_fitness

# Example usage:
def objective_function(x):
    # Example objective function (minimization problem)
    return np.sum(x**2)

# Define algorithm parameters
def opt(itr):
    N = 50
    max_iterations = itr

    # Initialize RSO_JSO optimizer
    optimizer = algm(objective_function, num_variables=5, num_rats=N, max_iterations=max_iterations)

    # Perform optimization
    best_position, best_fitness = optimizer.optimize()

    return best_fitness