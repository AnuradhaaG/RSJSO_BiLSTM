import numpy as np
import pandas as pd


def wilders_smoothing(data, window):
    """
    Calculate Welles Wilder's smoothing average (WMA) for the given data with the specified window size.

    Parameters:
        data (list or numpy array): A list or numpy array containing the data points.
        window (int): The window size for the moving average.

    Returns:
        list: A list containing the Wilder's smoothing average values.
    """
    smoothed_values = []
    weights = list(range(1, window + 1))

    for i in range(len(data) - window + 1):
        window_data = data[i:i + window]
        smoothed_value = sum(w * d for w, d in zip(weights, window_data)) / sum(weights)
        smoothed_values.append(smoothed_value)
    smoothed_values = np.array(smoothed_values)
    smoothed_values = np.resize(smoothed_values,(len(data),smoothed_values.shape[1]))
    return pd.DataFrame(smoothed_values)