
from sklearn.neighbors import NearestNeighbors
import numpy as np

import random
from sklearn.decomposition import PCA





def chooseNeighbor(neighbors_index, numNeighbors, to_be_removed):
    indices = neighbors_index[0]
    index_list = indices.tolist()
    index_list.remove(index_list[to_be_removed])
    index_list_size = len(index_list)
    if (index_list_size < numNeighbors):
        raise Exception('the num of neighbors if less than the number of points in the cluster')

    elif (index_list_size == numNeighbors):
        return index_list
    # remaining_rows = index_list.
    # create indices minus currRow
    else:
        listofselectedneighbors = []
        for i in range(numNeighbors):
            selected_index = random.choice(index_list)
            listofselectedneighbors.append(selected_index)
            index_list.remove(selected_index)
        return listofselectedneighbors

def get_lab(sz,lab):
    labb =[]
    k = len(lab)
    n = np.ceil(sz/len(lab))
    for i in range(int(n)):
        if i ==0:
            labb.append(list(lab))
            labb = np.array(labb)
        else:
            lab = lab.reshape(1, k)
            labb = np.concatenate((labb, lab),axis=1)
    return np.array(labb)
def pca(X):
    '''reduce data'''
    pca = PCA(n_components=2)
    Xreduced = pca.fit_transform(X, y=None)
    return Xreduced


def partitionSamples(X, Y):
    minority_rows = []
    majority_rows = []
    for i, row in enumerate(Y):
        if (1 == row):
            minority_rows.append(i)
        else:
            majority_rows.append(i)
    return (X[minority_rows], X[majority_rows])


def createSyntheticSamples(X, Y, nearestneigh, numNeighbors, majoritylabel, minoritylabel,aug_size):
    reducedX = pca(X)
    (Xminority, Xmajority) = partitionSamples(X, Y)
    numFeatures = Xminority.shape[1]
    Xreduced = pca(Xminority)
    numOrigMinority = len(Xminority)
    # reducedMinoritykmeans = KMeans(init='k-means++', max_iter=500,verbose=False,tol=1e-4,k=numCentroids, n_init=5, n_neighbors=3).fit(Xreduced)
    reducedNN = NearestNeighbors( algorithm='auto')
    reducedNN.fit(Xreduced)
    # Xsyn=np.array([numOrigMinority,numNeighbors*numFeatures])
    trylist = []
    # LOOPHERE  for EACH (minority) point...
    for j in range(5):
        for i, row in enumerate(Xreduced):
            neighbor_index = reducedNN.kneighbors(row.reshape(1, -1), return_distance=False)
            closestPoints = Xminority[neighbor_index]
            # randomly choose one of the k nearest neighbors
            chosenNeighborsIndex = chooseNeighbor(neighbor_index, numNeighbors, j)
            chosenNeighbor = Xminority[chosenNeighborsIndex]
            # Calculate linear combination:
            # Take te difference between the orig minority sample and its selected neighbor, where X[1,] is the orig point
            diff = Xminority[i,] - chosenNeighbor
            # Multiply this difference by a number between 0 and 1
            r = random.uniform(0, 1)
            # Add it back to te orig minority vector and viola this is the synthetic sample
            syth_sample = Xminority[i, :] + r * diff
            syth_sample2 = syth_sample.tolist()
            trylist.append(syth_sample2)
    trylist =np.array(trylist)
    Xsyn = np.resize(trylist, (aug_size, numFeatures))
    syth_Y = get_lab(aug_size,Y)
    maj_col = majoritylabel * np.ones([Xmajority.shape[0], 1])
    min_col = minoritylabel * np.ones([Xsyn.shape[0], 1])

    syth_X = np.concatenate((Xmajority, Xsyn), axis=0)
    syth_Y = syth_Y.T

    return (syth_X[0:aug_size], syth_Y[0:aug_size])


def augment(myX, Y,size):

    (Xsyn, Ysyn) = createSyntheticSamples(myX, Y, nearestneigh=20, numNeighbors=3, majoritylabel=0, minoritylabel=1,aug_size=size)
    return Xsyn, Ysyn